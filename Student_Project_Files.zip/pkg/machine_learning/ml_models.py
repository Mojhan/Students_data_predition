"""
Student Enrollment - Machine Learning
Tasks: (1) predict the COURSE a student will pick   (2) predict the BRANCH a student will join
       (3) forecast 2027 intake per branch / course (linear trend)
Run:  pip install pandas numpy scikit-learn matplotlib joblib openpyxl
      python ml_models.py
"""
import json, joblib, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, ConfusionMatrixDisplay, classification_report

df = pd.read_csv("students_clean.csv", dtype={"Phone": str})
print("Rows:", len(df))

# ---------- 1 & 2. Classification ----------
def run(target, features):
    X, y = df[features], df[target]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    pre = ColumnTransformer([("oh", OneHotEncoder(handle_unknown="ignore"), features)])
    models = {
        "Logistic Regression": LogisticRegression(max_iter=300),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=150, max_depth=12, n_jobs=-1, random_state=42),
    }
    base = (yte == ytr.mode()[0]).mean()
    rows, best, best_acc = [], None, -1
    for n, m in models.items():
        p = Pipeline([("pre", pre), ("m", m)]).fit(Xtr, ytr)
        pr = p.predict(Xte); acc = accuracy_score(yte, pr)
        cv = cross_val_score(Pipeline([("pre", pre), ("m", m)]), Xtr, ytr, cv=3).mean()
        rows.append({"target": target, "model": n, "accuracy": round(acc*100, 2),
                     "f1_weighted": round(f1_score(yte, pr, average="weighted")*100, 2), "cv_accuracy": round(cv*100, 2)})
        if acc > best_acc: best, best_acc, best_pred = p, acc, pr
    rows.append({"target": target, "model": "Baseline (majority class)", "accuracy": round(base*100, 2), "f1_weighted": None, "cv_accuracy": None})
    joblib.dump(best, f"best_{target.lower()}_model.joblib")
    fig, ax = plt.subplots(figsize=(8, 7))
    ConfusionMatrixDisplay(confusion_matrix(yte, best_pred, labels=sorted(y.unique())), display_labels=sorted(y.unique())).plot(ax=ax, xticks_rotation=60, colorbar=False)
    ax.set_title(f"Confusion matrix - predict {target}"); plt.tight_layout(); plt.savefig(f"confusion_{target.lower()}.png", dpi=120); plt.close()
    print(f"\n=== {target} ===\n", pd.DataFrame(rows).to_string(index=False))
    return rows

res = run("Course", ["Qualification", "QualLevel", "State", "Year", "Branch"]) + \
      run("Branch", ["Qualification", "QualLevel", "State", "Year", "Course"])
pd.DataFrame(res).to_csv("model_results.csv", index=False)

# ---------- 3. Forecast 2027 ----------
def forecast(col):
    t = df.pivot_table(index="Year", columns=col, values="S.No", aggfunc="count")
    X = t.index.values.reshape(-1, 1)
    out = {c: int(round(LinearRegression().fit(X, t[c]).predict([[2027]])[0])) for c in t.columns}
    f = pd.DataFrame({col: out.keys(), "Actual 2026": t.loc[2026].values, "Forecast 2027": out.values()})
    f["Share %"] = (f["Forecast 2027"] / f["Forecast 2027"].sum() * 100).round(1)
    return f
fb, fc = forecast("Branch"), forecast("Course")
fb.to_csv("forecast_branch_2027.csv", index=False); fc.to_csv("forecast_course_2027.csv", index=False)
print("\n", fb.to_string(index=False), "\n\n", fc.to_string(index=False))
fig, axs = plt.subplots(1, 2, figsize=(14, 5))
for ax, f, c in [(axs[0], fb, "Branch"), (axs[1], fc, "Course")]:
    f.set_index(c)[["Actual 2026", "Forecast 2027"]].plot.barh(ax=ax); ax.set_title(f"2027 forecast by {c}")
plt.tight_layout(); plt.savefig("forecast_2027.png", dpi=120)

# ---------- Example prediction ----------
m = joblib.load("best_course_model.joblib")
s = pd.DataFrame([{"Qualification": "B.E / B.Tech", "QualLevel": "UG", "State": "Tamil Nadu", "Year": 2027, "Branch": "Chennai - OMR"}])
print("\nExample - top 3 courses for a B.E student at OMR:")
pr = pd.Series(m.predict_proba(s)[0], index=m.classes_).sort_values(ascending=False).head(3)
print((pr*100).round(1).astype(str) + " %")
