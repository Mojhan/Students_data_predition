// Power BI Desktop > Home > Transform data > New Source > Blank Query > Advanced Editor. Change the file path.
let
  Source = Csv.Document(File.Contents("C:\Data\students_clean.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
  Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
  Typed = Table.TransformColumnTypes(Promoted, {{"S.No", Int64.Type}, {"Year", Int64.Type}, {"Phone", type text}}),
  Trimmed = Table.TransformColumns(Typed, {{"Name", Text.Trim, type text}, {"Email", each Text.Lower(Text.Trim(_)), type text}}),
  NoDup = Table.Distinct(Trimmed, {"EnrollmentNo"}),
  NoNulls = Table.SelectRows(NoDup, each [Course] <> null and [Branch] <> null),
  YearText = Table.AddColumn(NoNulls, "Year Label", each "FY " & Text.From([Year]), type text)
in
  YearText
