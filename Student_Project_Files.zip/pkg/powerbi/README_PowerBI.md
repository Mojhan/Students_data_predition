# Power BI Dashboard – build guide
A .pbix file can only be created inside Power BI Desktop, so this folder gives you everything to build it in about 15 minutes.

## Files
- `students_clean.csv` – 52,000 cleaned rows (main fact table)
- `forecast_branch_2027.csv`, `forecast_course_2027.csv` – 2027 forecasts
- `power_query.m` – cleaning steps (Power Query)
- `measures.dax` – all DAX measures

## Steps
1. Power BI Desktop > Get data > Text/CSV > load `students_clean.csv` (or use `power_query.m`), then load the two forecast CSVs.
2. Model view: no relationships needed; forecast tables are used on their own.
3. Modeling > New measure: paste each line from `measures.dax`.
4. Build the pages below. Set Theme: View > Themes.

## Page 1 – Overview
| Visual | Fields |
|---|---|
| Cards (x4) | Total Students, Distinct Branches, Distinct Courses, Top Course |
| Clustered bar | Axis: Branch, Value: Total Students |
| Donut | Legend: Course, Value: Total Students |
| Line chart | Axis: Year, Legend: Course, Value: Total Students |
| Slicers | City, Year, State, QualLevel |

## Page 2 – Branch × Course
| Visual | Fields |
|---|---|
| Matrix | Rows: Branch, Columns: Course, Values: Total Students (Conditional formatting > Background color scale) |
| Stacked column 100% | Axis: Branch, Legend: Course |
| Treemap | Group: Area, Values: Total Students |

## Page 3 – Students & Geography
| Visual | Fields |
|---|---|
| Filled map / bar | Location: State, Values: Total Students |
| Bar | Axis: District (Top N = 10), Values: Total Students |
| Bar | Axis: Qualification, Values: Total Students |

## Page 4 – Forecast 2027
| Visual | Fields |
|---|---|
| Clustered bar | Branch (forecast table), Forecast 2027 |
| Clustered bar | Course (forecast table), Forecast 2027 |
| Card | Forecast 2027 Branch |

Note: the data is synthetic (random), so the charts will look evenly spread and forecasts are flat. Real data will show real patterns.
