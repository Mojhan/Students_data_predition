# Student Enrollment Project
- `sql/` – schema, load script, cleaning checks, 10 analysis queries, ready-made SQLite DB (`students.db`)
- `powerbi/` – cleaned CSVs, Power Query (M), DAX measures, page-by-page build guide
- `machine_learning/` – `ml_models.py` (course/branch prediction + 2027 forecast), result CSVs and charts
Data is synthetic, so ML accuracy equals the random baseline.
