-- Data quality checks (every query should return 0 rows / 0)
SELECT COUNT(*) AS null_cells FROM students WHERE student_name IS NULL OR email IS NULL OR phone IS NULL OR district IS NULL OR state IS NULL;
SELECT enrollment_no, COUNT(*) c FROM students GROUP BY enrollment_no HAVING c>1;
SELECT email, COUNT(*) c FROM students GROUP BY email HAVING c>1;
SELECT phone, COUNT(*) c FROM students GROUP BY phone HAVING c>1;
SELECT COUNT(*) AS bad_phone FROM students WHERE LENGTH(phone)<>10 OR SUBSTR(phone,1,1) NOT IN ('6','7','8','9');
SELECT COUNT(*) AS bad_email FROM students WHERE email NOT LIKE '%_@_%._%';
SELECT COUNT(*) AS non_south FROM students WHERE state NOT IN ('Tamil Nadu','Kerala','Karnataka','Andhra Pradesh','Telangana','Puducherry');
-- Cleaning fixes (run if dirty data is ever loaded)
UPDATE students SET student_name=TRIM(student_name), email=LOWER(TRIM(email)), phone=TRIM(phone);
