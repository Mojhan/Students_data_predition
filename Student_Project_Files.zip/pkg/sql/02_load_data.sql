-- Step 1: load the flat CSV into a staging table, Step 2: split into the normalized tables.
DROP TABLE IF EXISTS stg_students;
CREATE TABLE stg_students ("S.No" INTEGER, EnrollmentNo TEXT, Name TEXT, Email TEXT, District TEXT, State TEXT, Phone TEXT,
  Qualification TEXT, QualLevel TEXT, Course TEXT, Branch TEXT, City TEXT, Area TEXT, Year INTEGER);

-- SQLite:   .mode csv  then  .import --skip 1 students_clean.csv stg_students
-- MySQL:    LOAD DATA LOCAL INFILE 'students_clean.csv' INTO TABLE stg_students FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' IGNORE 1 LINES;
-- Postgres: \copy stg_students FROM 'students_clean.csv' CSV HEADER

INSERT INTO branches(branch_name,city,area)       SELECT DISTINCT Branch,City,Area FROM stg_students ORDER BY Branch;
INSERT INTO courses(course_name)                  SELECT DISTINCT Course FROM stg_students ORDER BY Course;
INSERT INTO qualifications(qualification,qual_level) SELECT DISTINCT Qualification,QualLevel FROM stg_students ORDER BY Qualification;

INSERT INTO students(student_id,enrollment_no,student_name,email,phone,district,state,enroll_year,qual_id,course_id,branch_id)
SELECT s."S.No",s.EnrollmentNo,s.Name,LOWER(s.Email),s.Phone,s.District,s.State,s.Year,q.qual_id,c.course_id,b.branch_id
FROM stg_students s
JOIN qualifications q ON q.qualification=s.Qualification
JOIN courses c        ON c.course_name=s.Course
JOIN branches b       ON b.branch_name=s.Branch;
