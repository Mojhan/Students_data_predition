-- Student Enrollment Database (works on SQLite / MySQL / PostgreSQL with minor type tweaks)
DROP TABLE IF EXISTS students; DROP TABLE IF EXISTS branches; DROP TABLE IF EXISTS courses; DROP TABLE IF EXISTS qualifications;

CREATE TABLE branches (branch_id INTEGER PRIMARY KEY, branch_name VARCHAR(40) NOT NULL UNIQUE, city VARCHAR(20) NOT NULL, area VARCHAR(30) NOT NULL);
CREATE TABLE courses (course_id INTEGER PRIMARY KEY, course_name VARCHAR(40) NOT NULL UNIQUE);
CREATE TABLE qualifications (qual_id INTEGER PRIMARY KEY, qualification VARCHAR(40) NOT NULL UNIQUE, qual_level VARCHAR(10) NOT NULL);

CREATE TABLE students (
  student_id    INTEGER PRIMARY KEY,
  enrollment_no VARCHAR(20) NOT NULL UNIQUE,
  student_name  VARCHAR(60) NOT NULL,
  email         VARCHAR(80) NOT NULL UNIQUE,
  phone         CHAR(10)    NOT NULL UNIQUE CHECK (LENGTH(phone)=10),
  district      VARCHAR(40),
  state         VARCHAR(30),
  enroll_year   INTEGER NOT NULL,
  qual_id   INTEGER NOT NULL REFERENCES qualifications(qual_id),
  course_id INTEGER NOT NULL REFERENCES courses(course_id),
  branch_id INTEGER NOT NULL REFERENCES branches(branch_id)
);
CREATE INDEX idx_students_branch ON students(branch_id);
CREATE INDEX idx_students_course ON students(course_id);
CREATE INDEX idx_students_year   ON students(enroll_year);
