-- 1. Students per branch with share %
SELECT b.branch_name, COUNT(*) students, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM students),1) pct
FROM students s JOIN branches b USING(branch_id) GROUP BY b.branch_name ORDER BY students DESC;

-- 2. Students per course with share %
SELECT c.course_name, COUNT(*) students, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM students),1) pct
FROM students s JOIN courses c USING(course_id) GROUP BY c.course_name ORDER BY students DESC;

-- 3. Branch x course matrix (pivot)
SELECT b.branch_name,
  SUM(c.course_name='Data Science') data_science, SUM(c.course_name='Data Analysis') data_analysis,
  SUM(c.course_name='Python Full Stack') python_fs, SUM(c.course_name='Java Full Stack') java_fs,
  SUM(c.course_name='Manual Testing') manual_testing, SUM(c.course_name='UI/UX') ui_ux, SUM(c.course_name='Cyber Security') cyber
FROM students s JOIN branches b USING(branch_id) JOIN courses c USING(course_id) GROUP BY b.branch_name;

-- 4. Yearly intake and year-over-year growth per branch
WITH y AS (SELECT b.branch_name, s.enroll_year yr, COUNT(*) n FROM students s JOIN branches b USING(branch_id) GROUP BY 1,2)
SELECT branch_name, yr, n, LAG(n) OVER (PARTITION BY branch_name ORDER BY yr) prev,
  ROUND(100.0*(n-LAG(n) OVER (PARTITION BY branch_name ORDER BY yr))/LAG(n) OVER (PARTITION BY branch_name ORDER BY yr),1) yoy_pct
FROM y ORDER BY branch_name, yr;

-- 5. Most popular course in each branch (window function)
SELECT * FROM (
  SELECT b.branch_name, c.course_name, COUNT(*) n,
         RANK() OVER (PARTITION BY b.branch_name ORDER BY COUNT(*) DESC) rk
  FROM students s JOIN branches b USING(branch_id) JOIN courses c USING(course_id) GROUP BY 1,2)
WHERE rk=1;

-- 6. Course preference by qualification level
SELECT q.qual_level, c.course_name, COUNT(*) n,
  ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY q.qual_level),1) pct_in_level
FROM students s JOIN qualifications q USING(qual_id) JOIN courses c USING(course_id) GROUP BY 1,2 ORDER BY 1,3 DESC;

-- 7. Top 10 native districts
SELECT district, state, COUNT(*) n FROM students GROUP BY 1,2 ORDER BY n DESC LIMIT 10;

-- 8. Chennai vs Bangalore
SELECT b.city, COUNT(*) students FROM students s JOIN branches b USING(branch_id) GROUP BY b.city;

-- 9. Simple 2027 forecast: 2026 count + average yearly change (2023-2026)
WITH y AS (SELECT branch_id, enroll_year yr, COUNT(*) n FROM students GROUP BY 1,2),
t AS (SELECT branch_id,
        MAX(CASE WHEN yr=2026 THEN n END) n26,
        (MAX(CASE WHEN yr=2026 THEN n END)-MAX(CASE WHEN yr=2023 THEN n END))/3.0 avg_change FROM y GROUP BY 1)
SELECT b.branch_name, n26 AS actual_2026, ROUND(n26+avg_change) AS forecast_2027
FROM t JOIN branches b USING(branch_id) ORDER BY forecast_2027 DESC;

-- 10. View for BI tools
DROP VIEW IF EXISTS vw_student_report;
CREATE VIEW vw_student_report AS
SELECT s.student_id,s.enrollment_no,s.student_name,s.email,s.phone,s.district,s.state,s.enroll_year,
       q.qualification,q.qual_level,c.course_name,b.branch_name,b.city,b.area
FROM students s JOIN qualifications q USING(qual_id) JOIN courses c USING(course_id) JOIN branches b USING(branch_id);
